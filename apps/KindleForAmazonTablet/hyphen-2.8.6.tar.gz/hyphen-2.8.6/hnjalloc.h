/* LibHnj is dual licensed under LGPL and MPL. Boilerplate for both
 * licenses follows.
 */

/* LibHnj - a library for high quality hyphenation and justification
 * Copyright (C) 1998 Raph Levien
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330, 
 * Boston, MA  02111-1307  USA.
*/

/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "MPL"); you may not use this file except in
 * compliance with the MPL.  You may obtain a copy of the MPL at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the MPL is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the MPL
 * for the specific language governing rights and limitations under the
 * MPL.
 *
 */
/* wrappers for malloc */

/**
 * Alloc callback method for allocating memory. Should return NULL if memory is not available.
 */
typedef void* hnj_alloc_fn(size_t size);

/**
 * Realloc callback to reallocate the memory for the objects created through hnj_alloc_fn or hnj_alloc_temp_fn. 
 */
typedef void* hnj_realloc_fn(void *mem, size_t size);

/**
 * Callback method type to free the memory allocated through hnj_alloc_fn, hnj_alloc_temp_fn or hnj_realloc_fn.
 */
typedef void  hnj_free_fn(void *mem);

extern hnj_alloc_fn *hnj_malloc;
extern hnj_alloc_fn *hnj_malloc_temp;
extern hnj_free_fn *hnj_free;
extern hnj_realloc_fn *hnj_realloc;

/**
 * Sets the alloc methods for hnj else points to regular methods.
 *
 * @param alloc_fn The allocation callback, cannot be NULL.
 * @param alloc_temp_fn The allocation callback for temporary objects. Utility method to avoid memory fragmentation while 
 *        creating temporary objects. This is helpful in creating temporary objects (like from a local pre-allocated pool) that are 
 *        transient in nature and are freed quickly. If NULL then alloc_fn is used for all allocations.
 * @param realloc_fn The reallocation callback, cannot be NULL.
 * @param free_fn The free memory callback. Should work will all types of allocations, cannot be NULL.
 */
void hnj_set_alloc_methods(hnj_alloc_fn * alloc_fn, hnj_alloc_fn * alloc_temp_fn,
                           hnj_realloc_fn * realloc_fn, hnj_free_fn * free_fn);

/**
 * Resets the alloc methods to the original ones.
 */
void hnj_reset_alloc_methods(void);



