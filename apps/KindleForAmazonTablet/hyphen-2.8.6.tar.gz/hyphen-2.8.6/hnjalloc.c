/* LibHnj is dual licensed under LGPL and MPL. Boilerplate for both
 * licenses follows.
 */

/* LibHnj - a library for high quality hyphenation and justification
 * Copyright (C) 1998 Raph Levien, (C) 2001 ALTLinux, Moscow
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330, 
 * Boston, MA  02111-1307  USA.
*/

/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "MPL"); you may not use this file except in
 * compliance with the MPL.  You may obtain a copy of the MPL at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the MPL is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the MPL
 * for the specific language governing rights and limitations under the
 * MPL.
 *
 */
/* wrappers for malloc */

#include <stdlib.h>
#include <stdio.h>
#include "hnjalloc.h"

static void * hnj_malloc_internal (size_t size);
static void * hnj_realloc_internal (void *p, size_t size);
static void hnj_free_internal (void *p);

hnj_alloc_fn * hnj_malloc = hnj_malloc_internal;
hnj_alloc_fn *  hnj_malloc_temp = hnj_malloc_internal;
hnj_free_fn *hnj_free = hnj_free_internal;
hnj_realloc_fn *hnj_realloc = hnj_realloc_internal;

void
hnj_set_alloc_methods(hnj_alloc_fn * alloc_fn, hnj_alloc_fn * alloc_temp_fn, hnj_realloc_fn * realloc_fn, hnj_free_fn * free_fn)
{
    hnj_malloc = alloc_fn;
    hnj_realloc = realloc_fn;
    hnj_free = free_fn;
    
    if(alloc_temp_fn != NULL)
    {
        hnj_malloc_temp = alloc_temp_fn;
    }
    else
    {
        hnj_malloc_temp = alloc_fn;
    }/* end else if */
}/* end method hnj_set_alloc_methods */

/**
 * Resets the alloc methods to the original ones.
 */
void
hnj_reset_alloc_methods(void)
{
    hnj_malloc = hnj_malloc_internal;
    hnj_malloc_temp = hnj_malloc_internal;
    hnj_free = hnj_free_internal;
    hnj_realloc = hnj_realloc_internal;
}/* end method hnj_reset_alloc_methods */

static void *
hnj_malloc_internal (size_t size)
{
  void *p;

  p = malloc (size);
  if (p == NULL)
    {
      fprintf (stderr, "can't allocate %zu bytes\n", size);
      exit (1);
    }
  return p;
}

static void *
hnj_realloc_internal (void *p, size_t size)
{
  p = realloc (p, size);
  if (p == NULL)
    {
      fprintf (stderr, "can't allocate %zu bytes\n", size);
      exit (1);
    }
  return p;
}

static void
hnj_free_internal (void *p)
{
  free (p);
}

